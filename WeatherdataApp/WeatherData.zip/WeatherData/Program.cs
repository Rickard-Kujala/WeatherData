﻿using System;
using System.IO;

namespace WeatherData.CoreApp
{
    class Program
    {
        static void Main(string[] args)
        {
            LoadFromFile();
            Console.ReadLine();
            

        }

        static string[] LoadFromFile()
        {
            string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory + "TemperaturData.csv");
            string[] data = File.ReadAllLines(path);

            foreach (var item in data)
            {
                Console.WriteLine(item);
            }
            return data;
        }
    }
}
