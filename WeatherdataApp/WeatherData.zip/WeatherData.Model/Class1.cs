﻿using System;

namespace WeatherData.Model
{
    public class Class1
    {


    }
}
