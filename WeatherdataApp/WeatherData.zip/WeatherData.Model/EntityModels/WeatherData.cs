﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherData.Model.EntityModels
{
    public class WeatherData
    {
        public int Id { get; set; }
        public Sensor Sensor { get; set; }
        public DateTime Time { get; set; }
        public decimal Temp { get; set; }
        public int Humidity { get; set; }

    }
}
